import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SingletonDesingPattern {
	public static void main(String[] args) {
		
		//Kitchen theKitchen7 = new Kitchen();
		
		Kitchen theKitchen1 = Kitchen.getKitchen();
		Kitchen theKitchen2 = Kitchen.getKitchen();
		Kitchen theKitchen3 = Kitchen.getKitchen();
		Kitchen theKitchen4 = Kitchen.getKitchen();
		Kitchen theKitchen5 = Kitchen.getKitchen();
		Kitchen theKitchen6 = Kitchen.getKitchen();
		
		
		System.out.println("theKitchen1 : "+theKitchen1.hashCode());
		System.out.println("theKitchen2 : "+theKitchen2.hashCode());
		System.out.println("theKitchen3 : "+theKitchen3.hashCode());
		System.out.println("theKitchen4 : "+theKitchen4.hashCode());
		System.out.println("theKitchen5 : "+theKitchen5.hashCode());
		System.out.println("theKitchen6 : "+theKitchen6.hashCode());
		
		Connection conn1 = MyConnection.getConnection();
		Connection conn2 = MyConnection.getConnection();
		Connection conn3 = MyConnection.getConnection();
		
		System.out.println("conn1 "+conn1.hashCode());
		System.out.println("conn2 "+conn2.hashCode());
		System.out.println("conn3 "+conn3.hashCode());
		
		

	}
}

class Kitchen
{
	//some data and functions related to the real life kitchen

	private static Kitchen ref; // default value is null | sharable ref 
	
	private Kitchen () {
		System.out.println("Kitchen() ctor");
	}
	public static Kitchen getKitchen() {
		if(ref == null)
			ref = new Kitchen();
		
		
		return ref;
	}
}

class MyConnection
{
	//some data and functions related to the real life kitchen

	private static Connection conn; // default value is null | sharable ref 
	
	private MyConnection () {
		System.out.println("MyConnection() ctor");
	}
	public static Connection getConnection() {
		if(conn == null) {
			try {
				DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
				System.out.println("Driver registered....");

				conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb","SA","");
				System.out.println("Connected...");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return conn;
	}
}
